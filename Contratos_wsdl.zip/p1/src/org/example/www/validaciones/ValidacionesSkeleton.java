
/**
 * ValidacionesSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
    package org.example.www.validaciones;
    /**
     *  ValidacionesSkeleton java skeleton for the axisService
     */
    public class ValidacionesSkeleton implements ValidacionesSkeletonInterface{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param validarIBAN0 
             * @return validarIBANResponse1 
         */
        
                 public org.example.www.validaciones.ValidarIBANResponse validarIBAN
                  (
                  org.example.www.validaciones.ValidarIBAN validarIBAN0
                  )
            {
                	 ValidarIBANResponse response = new ValidarIBANResponse();
                	 String iban = validarIBAN0.getIban();
                	 boolean result = false;
                	 if (iban != null) {
                         iban = iban.replaceAll("\\s+", "").toUpperCase();
                         if (iban.matches("ES[0-9]{22}")) {
                             String rearranged = iban.substring(4) + iban.substring(0, 4);
                             String numeric = rearranged.replace("E", "14").replace("S", "28");
                             java.math.BigInteger bigInt = new java.math.BigInteger(numeric);
                             result = bigInt.mod(java.math.BigInteger.valueOf(97))
                                            .equals(java.math.BigInteger.ONE);
                         }
                     }
                     response.setOut(result);
                     return response;
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param validarNAF2 
             * @return validarNAFResponse3 
         */
        
                 public org.example.www.validaciones.ValidarNAFResponse validarNAF
                  (
                  org.example.www.validaciones.ValidarNAF validarNAF2
                  )
            {
                	 ValidarNAFResponse response= new ValidarNAFResponse();
                	 String naf = validarNAF2.getNaf();
                	 boolean result = false;
                	 
                	 if(naf != null){
                		 naf = naf.trim();
                		 result = naf.matches("[0-9]{12}");
                	 }
                	 response.setOut(result);
                	 return response;
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param validarNIF4 
             * @return validarNIFResponse5 
         */
        
                 public org.example.www.validaciones.ValidarNIFResponse validarNIF
                  (
                  org.example.www.validaciones.ValidarNIF validarNIF4
                  )
            {
                	 ValidarNIFResponse response = new ValidarNIFResponse();
                	 String nif = validarNIF4.getNif();
                	 boolean result = false;
                	 
                	 if(nif != null){
                		 nif =nif.toUpperCase().trim();
                		 if (nif.matches("[0-9]{8}[A-Z]")) {
                             String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
                             int num = Integer.parseInt(nif.substring(0, 8));
                             char letraCorrecta = letras.charAt(num % 23);
                             result = (nif.charAt(8) == letraCorrecta);
                         }
                	 }
                	 response.setOut(result);
                	 return response;
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param validarNIE6 
             * @return validarNIEResponse7 
         */
        
                 public org.example.www.validaciones.ValidarNIEResponse validarNIE
                  (
                  org.example.www.validaciones.ValidarNIE validarNIE6
                  )
            {
                //TODO : fill this with the necessary business logic
                ValidarNIEResponse response = new ValidarNIEResponse();
                String nie = validarNIE6.getNie();
                boolean result = false;
                
                if(nie != null){
                	nie = nie.toUpperCase().trim();
                	if(nie.matches("[XYZ][0-9]{7}[A-Z]")){
                		String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
                        // Replace leading letter: X=0, Y=1, Z=2
                        String nieNum = nie.replace('X', '0')
                                           .replace('Y', '1')
                                           .replace('Z', '2');
                        int num = Integer.parseInt(nieNum.substring(0,8));
                        char letraCorrecta = letras.charAt(num % 23);
                        result = (nie.charAt(8) == letraCorrecta);
                	}
                }
                response.setOut(result);
                return response;
        }
     
    }
    