
/**
 * ValidacionesSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
    package org.example.www.validaciones;
    /**
     *  ValidacionesSkeletonInterface java skeleton interface for the axisService
     */
    public interface ValidacionesSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param validarIBAN
         */

        
                public org.example.www.validaciones.ValidarIBANResponse validarIBAN
                (
                  org.example.www.validaciones.ValidarIBAN validarIBAN
                 )
            ;
        
         
        /**
         * Auto generated method signature
         * 
                                    * @param validarNAF
         */

        
                public org.example.www.validaciones.ValidarNAFResponse validarNAF
                (
                  org.example.www.validaciones.ValidarNAF validarNAF
                 )
            ;
        
         
        /**
         * Auto generated method signature
         * 
                                    * @param validarNIF
         */

        
                public org.example.www.validaciones.ValidarNIFResponse validarNIF
                (
                  org.example.www.validaciones.ValidarNIF validarNIF
                 )
            ;
        
         
        /**
         * Auto generated method signature
         * 
                                    * @param validarNIE
         */

        
                public org.example.www.validaciones.ValidarNIEResponse validarNIE
                (
                  org.example.www.validaciones.ValidarNIE validarNIE
                 )
            ;
        
         }
    