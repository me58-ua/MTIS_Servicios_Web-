
/**
 * ControlPresenciaSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
    package org.example.www.controlpresencia;
    /**
     *  ControlPresenciaSkeletonInterface java skeleton interface for the axisService
     */
    public interface ControlPresenciaSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param registrar
         */

        
                public org.example.www.controlpresencia.RegistrarResponse registrar
                (
                  org.example.www.controlpresencia.Registrar registrar
                 )
            ;
        
         
        /**
         * Auto generated method signature
         * 
                                    * @param eliminar
         */

        
                public org.example.www.controlpresencia.EliminarResponse eliminar
                (
                  org.example.www.controlpresencia.Eliminar eliminar
                 )
            ;
        
         
        /**
         * Auto generated method signature
         * 
                                    * @param controlEmpleadosSala
         */

        
                public org.example.www.controlpresencia.ControlEmpleadosSalaResponse controlEmpleadosSala
                (
                  org.example.www.controlpresencia.ControlEmpleadosSala controlEmpleadosSala
                 )
            ;
        
         }
    