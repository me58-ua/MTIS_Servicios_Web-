
/**
 * ControlPresenciaSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
    package org.example.www.controlpresencia;
    
    import java.sql.*;
    /**
     *  ControlPresenciaSkeleton java skeleton for the axisService
     */
    public class ControlPresenciaSkeleton implements ControlPresenciaSkeletonInterface{
    	
    	private static final String DB_URL =
    	        "jdbc:mysql://127.0.0.1:3307/practica1"
    	        + "?useUnicode=true"
    	        + "&characterEncoding=UTF-8"
    	        + "&useSSL=false"
    	        + "&serverTimezone=UTC";
    	private static final String DB_USER = "root";
    	private static final String DB_PASS = "root";
        
    	private Connection getConnection() throws SQLException {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException("MySQL Driver not found", e);
            }
            return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
        }
    	    
        /**
         * Auto generated method signature
         * 
                                     * @param registrar0 
             * @return registrarResponse1 
         */
        
                 public org.example.www.controlpresencia.RegistrarResponse registrar
                  (
                  org.example.www.controlpresencia.Registrar registrar0
                  )
            {
                	 RegistrarResponse response = new RegistrarResponse();
                	 try (Connection conn = getConnection()) {
                         PreparedStatement psEmp = conn.prepareStatement(
                             "SELECT id FROM empleados WHERE nifnie = ?");
                         psEmp.setString(1, registrar0.getNif());
                         ResultSet rsEmp = psEmp.executeQuery();
                         if (!rsEmp.next()) { response.setOut(false); return response; }
                         int idEmpleado = rsEmp.getInt("id");

                         PreparedStatement psSala = conn.prepareStatement(
                             "SELECT id FROM salas WHERE codigoSala = ?");
                         psSala.setInt(1, registrar0.getCodigosala());
                         ResultSet rsSala = psSala.executeQuery();
                         if (!rsSala.next()) { response.setOut(false); return response; }
                         int idSala = rsSala.getInt("id");

                         PreparedStatement psInsert = conn.prepareStatement(
                             "INSERT INTO controlpresencia (idEmpleado, idSala, fechahora) " +
                             "VALUES (?, ?, NOW())");
                         psInsert.setInt(1, idEmpleado);
                         psInsert.setInt(2, idSala);
                         psInsert.executeUpdate();
                         response.setOut(true);

                     } catch (SQLException e) {
                         System.out.println(">>> SQL ERROR registrar: " + e.getMessage());
                         e.printStackTrace();
                         response.setOut(false);
                     }
                     return response;
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param eliminar2 
             * @return eliminarResponse3 
         */
        
                 public org.example.www.controlpresencia.EliminarResponse eliminar
                  (
                  org.example.www.controlpresencia.Eliminar eliminar2
                  )
            {
                	 EliminarResponse response = new EliminarResponse();

                     try (Connection conn = getConnection()) {

                         // Get idEmpleado
                         PreparedStatement psEmp = conn.prepareStatement(
                             "SELECT id FROM empleados WHERE nifnie = ?");
                         psEmp.setString(1, eliminar2.getNif());
                         ResultSet rsEmp = psEmp.executeQuery();
                         if (!rsEmp.next()) { response.setOut(false); return response; }
                         int idEmpleado = rsEmp.getInt("id");
                         
                         PreparedStatement psSala = conn.prepareStatement(
                             "SELECT id FROM salas WHERE codigoSala = ?");
                         psSala.setInt(1, eliminar2.getCodigosala());
                         ResultSet rsSala = psSala.executeQuery();
                         if (!rsSala.next()) { response.setOut(false); return response; }
                         int idSala = rsSala.getInt("id");

                         PreparedStatement psDelete = conn.prepareStatement(
                             "DELETE FROM controlpresencia " +
                             "WHERE idEmpleado = ? AND idSala = ?");
                         psDelete.setInt(1, idEmpleado);
                         psDelete.setInt(2, idSala);
                         int rows = psDelete.executeUpdate();
                         response.setOut(rows > 0);

                     } catch (SQLException e) {
                         System.out.println(">>> SQL ERROR eliminar: " + e.getMessage());
                         e.printStackTrace();
                         response.setOut(false);
                     }
                     return response;
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param controlEmpleadosSala4 
             * @return controlEmpleadosSalaResponse5 
         */
        
                 public org.example.www.controlpresencia.ControlEmpleadosSalaResponse controlEmpleadosSala
                  (
                  org.example.www.controlpresencia.ControlEmpleadosSala controlEmpleadosSala4
                  )
            {
                	 ControlEmpleadosSalaResponse response = new ControlEmpleadosSalaResponse();

                     try (Connection conn = getConnection()) {

                         String sql = "SELECT e.id, e.nifnie, e.nombreApellidos, e.email, " +
                                      "e.naf, e.iban, e.idNivel, e.usuario, e.password, e.valido " +
                                      "FROM controlpresencia cp " +
                                      "JOIN empleados e ON cp.idEmpleado = e.id " +
                                      "JOIN salas s ON cp.idSala = s.id " +
                                      "WHERE s.codigoSala = ?";

                         PreparedStatement ps = conn.prepareStatement(sql);
                         ps.setInt(1, controlEmpleadosSala4.getCodigosala());
                         ResultSet rs = ps.executeQuery();

                         java.util.List<Empleado> lista = new java.util.ArrayList<>();
                         while (rs.next()) {
                        	 Empleado emp = new Empleado();
                        	    emp.setId(rs.getInt("id"));
                        	    emp.setNifnie(rs.getString("nifnie"));
                        	    emp.setNombreApellidos(rs.getString("nombreApellidos"));
                        	    emp.setEmail(rs.getString("email"));
                        	    emp.setNaf(rs.getString("naf"));
                        	    emp.setIban(rs.getString("iban"));
                        	    emp.setIdNivel(rs.getInt("idNivel"));
                        	    emp.setUsuario(rs.getString("usuario"));
                        	    emp.setPassword(rs.getString("password"));
                        	    emp.setValido(rs.getBoolean("valido"));
                        	    lista.add(emp);
                         }

                         ArrayOfEmpleados arrayOut = new ArrayOfEmpleados();
                         arrayOut.setEmpleados(lista.toArray(new Empleado[0]));
                         response.setOut(arrayOut);
                     } catch (SQLException e) {
                    	 System.out.println(">>> SQL ERROR controlEmpleadosSala: " + e.getMessage());
                         e.printStackTrace();
                         response.setOut(new ArrayOfEmpleados());
                     }
                     return response;
        }
     
    }
    