
/**
 * EmpleadosSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
    package org.example.www.empleados;
    
    import java.sql.*;
    /**
     *  EmpleadosSkeleton java skeleton for the axisService
     */
    public class EmpleadosSkeleton implements EmpleadosSkeletonInterface{
    	private static final String DB_URL =
    		    "jdbc:mysql://127.0.0.1:3307/practica1"
    		    + "?useUnicode=true"
    		    + "&characterEncoding=UTF-8"
    		    + "&useSSL=false"
    		    + "&sendConnectionAttributes=false";
        private static final String DB_USER = "root";
        private static final String DB_PASS = "root";
         
        private Connection getConnection() throws SQLException {
            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException("MySQL Driver not found", e);
            }
            return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
        }
        
        /**
         * Auto generated method signature
         * 
                                     * @param modificar0 
             * @return modificarResponse1 
         */
        
                 public org.example.www.empleados.ModificarResponse modificar
                  (
                  org.example.www.empleados.Modificar modificar0
                  )
            {
                	 ModificarResponse response = new ModificarResponse();
                	 Empleado emp = modificar0.getIn();
                	 
                	 try (Connection conn = getConnection()) {
                         String sql = "UPDATE empleados SET " +
                             "nombreApellidos=?, email=?, naf=?, iban=?, " +
                             "idNivel=?, usuario=?, password=?, valido=? " +
                             "WHERE nifnie=?";
                         PreparedStatement ps = conn.prepareStatement(sql);
                         ps.setString(1,  emp.getNombreApellidos());
                         ps.setString(2,  emp.getEmail());
                         ps.setString(3,  emp.getNaf());
                         ps.setString(4,  emp.getIban());
                         ps.setInt(5,     emp.getIdNivel());
                         ps.setString(6,  emp.getUsuario());
                         ps.setString(7,  emp.getPassword());
                         ps.setBoolean(8, emp.getValido());
                         ps.setString(9,  emp.getNifnie());
                         int rows = ps.executeUpdate();
                         response.setOut(rows > 0);
                     } catch (SQLException e) {
                         response.setOut(false);
                     }
                     return response;
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param consultar2 
             * @return consultarResponse3 
         */
        
                 public org.example.www.empleados.ConsultarResponse consultar
                  (
                  org.example.www.empleados.Consultar consultar2
                  )
            {
                	 ConsultarResponse response = new ConsultarResponse();
                	    Empleado empVacio = new Empleado();

                	    try (Connection conn = getConnection()) {
                	        String nif = consultar2.getNif();
                	        System.out.println(">>> BUSCANDO NIF: [" + nif + "]"); // shows exact value + spaces

                	        String sql = "SELECT * FROM empleados WHERE nifnie = ?";
                	        PreparedStatement ps = conn.prepareStatement(sql);
                	        ps.setString(1, nif);
                	        ResultSet rs = ps.executeQuery();

                	        if (rs.next()) {
                	            System.out.println(">>> EMPLEADO ENCONTRADO");
                	            Empleado emp = new Empleado();
                	            emp.setId(rs.getInt("id"));
                	            emp.setNifnie(rs.getString("nifnie"));
                	            emp.setNombreApellidos(rs.getString("nombreApellidos"));
                	            emp.setEmail(rs.getString("email"));
                	            emp.setNaf(rs.getString("naf"));
                	            emp.setIban(rs.getString("iban"));
                	            emp.setIdNivel(rs.getInt("idNivel"));
                	            emp.setUsuario(rs.getString("usuario"));
                	            emp.setPassword(rs.getString("password"));
                	            emp.setValido(rs.getBoolean("valido"));
                	            response.setOut(emp);
                	        } else {
                	            System.out.println(">>> NO ENCONTRADO");
                	            response.setOut(empVacio);
                	        }
                	    } catch (SQLException e) {
                	    	System.out.println(">>> SQL ERROR: " + e.getMessage());
                	        e.printStackTrace();
                	        empVacio.setNifnie("");
                	        empVacio.setNombreApellidos("");
                	        empVacio.setEmail("");
                	        empVacio.setNaf("");
                	        empVacio.setIban("");
                	        empVacio.setUsuario("");
                	        empVacio.setPassword("");
                	        empVacio.setIdNivel(0);
                	        empVacio.setValido(false);
                	        response.setOut(empVacio);
                	    }
                	    return response;
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param nuevo4 
             * @return nuevoResponse5 
         */
        
                 public org.example.www.empleados.NuevoResponse nuevo
                  (
                  org.example.www.empleados.Nuevo nuevo4
                  )
            {
                	 NuevoResponse response = new NuevoResponse();

                     Empleado emp = nuevo4.getIn();

                     org.example.www.validaciones.ValidacionesSkeleton val =
                         new org.example.www.validaciones.ValidacionesSkeleton();

                     org.example.www.validaciones.ValidarNIF nifReq =
                         new org.example.www.validaciones.ValidarNIF();
                     nifReq.setNif(emp.getNifnie());
                     boolean identidadValida = val.validarNIF(nifReq).getOut();

                     if (!identidadValida) {
                         org.example.www.validaciones.ValidarNIE nieReq =
                             new org.example.www.validaciones.ValidarNIE();
                         nieReq.setNie(emp.getNifnie());
                         identidadValida = val.validarNIE(nieReq).getOut();
                     }

                     org.example.www.validaciones.ValidarNAF nafReq =
                         new org.example.www.validaciones.ValidarNAF();
                     nafReq.setNaf(emp.getNaf());
                     boolean nafValido = val.validarNAF(nafReq).getOut();

                     org.example.www.validaciones.ValidarIBAN ibanReq =
                         new org.example.www.validaciones.ValidarIBAN();
                     ibanReq.setIban(emp.getIban());
                     boolean ibanValido = val.validarIBAN(ibanReq).getOut();

                     if (!identidadValida || !nafValido || !ibanValido) {
                         response.setOut(false);
                         return response;
                     }

                     // Insertar
                     try (Connection conn = getConnection()) {
                         String sql = "INSERT INTO empleados " +
                             "(nifnie, nombreApellidos, email, naf, iban, idNivel, usuario, password, valido) " +
                             "VALUES (?,?,?,?,?,?,?,?,?)";
                         PreparedStatement ps = conn.prepareStatement(sql);
                         ps.setString(1,  emp.getNifnie());
                         ps.setString(2,  emp.getNombreApellidos());
                         ps.setString(3,  emp.getEmail());
                         ps.setString(4,  emp.getNaf());
                         ps.setString(5,  emp.getIban());
                         ps.setInt(6,     emp.getIdNivel());
                         ps.setString(7,  emp.getUsuario());
                         ps.setString(8,  emp.getPassword());
                         ps.setBoolean(9, emp.getValido());
                         ps.executeUpdate();
                         response.setOut(true);
                     } catch (SQLException e) {
                         response.setOut(false);
                     }
                     return response;
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param borrar6 
             * @return borrarResponse7 
         */
        
                 public org.example.www.empleados.BorrarResponse borrar
                  (
                  org.example.www.empleados.Borrar borrar6
                  )
            {
                	 BorrarResponse response = new BorrarResponse();

                     try (Connection conn = getConnection()) {
                         String sql = "DELETE FROM empleados WHERE nifnie = ?";
                         PreparedStatement ps = conn.prepareStatement(sql);
                         ps.setString(1, borrar6.getNif());
                         int rows = ps.executeUpdate();
                         response.setOut(rows > 0);
                     } catch (SQLException e) {
                         response.setOut(false);
                     }
                     return response;
        }
     
    }
    