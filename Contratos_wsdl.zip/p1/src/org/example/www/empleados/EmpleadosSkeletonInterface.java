
/**
 * EmpleadosSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
    package org.example.www.empleados;
    /**
     *  EmpleadosSkeletonInterface java skeleton interface for the axisService
     */
    public interface EmpleadosSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param modificar
         */

        
                public org.example.www.empleados.ModificarResponse modificar
                (
                  org.example.www.empleados.Modificar modificar
                 )
            ;
        
         
        /**
         * Auto generated method signature
         * 
                                    * @param consultar
         */

        
                public org.example.www.empleados.ConsultarResponse consultar
                (
                  org.example.www.empleados.Consultar consultar
                 )
            ;
        
         
        /**
         * Auto generated method signature
         * 
                                    * @param nuevo
         */

        
                public org.example.www.empleados.NuevoResponse nuevo
                (
                  org.example.www.empleados.Nuevo nuevo
                 )
            ;
        
         
        /**
         * Auto generated method signature
         * 
                                    * @param borrar
         */

        
                public org.example.www.empleados.BorrarResponse borrar
                (
                  org.example.www.empleados.Borrar borrar
                 )
            ;
        
         }
    