
/**
 * EmpleadosCallbackHandler.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */

    package org.example.www.empleados;

    /**
     *  EmpleadosCallbackHandler Callback class, Users can extend this class and implement
     *  their own receiveResult and receiveError methods.
     */
    public abstract class EmpleadosCallbackHandler{



    protected Object clientData;

    /**
    * User can pass in any object that needs to be accessed once the NonBlocking
    * Web service call is finished and appropriate method of this CallBack is called.
    * @param clientData Object mechanism by which the user can pass in user data
    * that will be avilable at the time this callback is called.
    */
    public EmpleadosCallbackHandler(Object clientData){
        this.clientData = clientData;
    }

    /**
    * Please use this constructor if you don't want to set any clientData
    */
    public EmpleadosCallbackHandler(){
        this.clientData = null;
    }

    /**
     * Get the client data
     */

     public Object getClientData() {
        return clientData;
     }

        
           /**
            * auto generated Axis2 call back method for modificar method
            * override this method for handling normal response from modificar operation
            */
           public void receiveResultmodificar(
                    org.example.www.empleados.ModificarResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from modificar operation
           */
            public void receiveErrormodificar(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for consultar method
            * override this method for handling normal response from consultar operation
            */
           public void receiveResultconsultar(
                    org.example.www.empleados.ConsultarResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from consultar operation
           */
            public void receiveErrorconsultar(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for nuevo method
            * override this method for handling normal response from nuevo operation
            */
           public void receiveResultnuevo(
                    org.example.www.empleados.NuevoResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from nuevo operation
           */
            public void receiveErrornuevo(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for borrar method
            * override this method for handling normal response from borrar operation
            */
           public void receiveResultborrar(
                    org.example.www.empleados.BorrarResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from borrar operation
           */
            public void receiveErrorborrar(java.lang.Exception e) {
            }
                


    }
    