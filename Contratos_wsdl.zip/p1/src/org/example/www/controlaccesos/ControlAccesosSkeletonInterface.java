
/**
 * ControlAccesosSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
    package org.example.www.controlaccesos;
    /**
     *  ControlAccesosSkeletonInterface java skeleton interface for the axisService
     */
    public interface ControlAccesosSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param consultar
         */

        
                public org.example.www.controlaccesos.ConsultarResponse consultar
                (
                  org.example.www.controlaccesos.Consultar consultar
                 )
            ;
        
         
        /**
         * Auto generated method signature
         * 
                                    * @param registrar
         */

        
                public org.example.www.controlaccesos.RegistrarResponse registrar
                (
                  org.example.www.controlaccesos.Registrar registrar
                 )
            ;
        
         }
    