
/**
 * ControlAccesosSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
    package org.example.www.controlaccesos;
    
    import java.sql.*;
    /**
     *  ControlAccesosSkeleton java skeleton for the axisService
     */
    public class ControlAccesosSkeleton implements ControlAccesosSkeletonInterface{
    	 private static final String DB_URL =
                 "jdbc:mysql://127.0.0.1:3307/practica1"
                         + "?useUnicode=true"
                         + "&characterEncoding=UTF-8"
                         + "&useSSL=false"
                         + "&serverTimezone=UTC";
         private static final String DB_USER = "root";
         private static final String DB_PASS = "root";
         
         private Connection getConnection() throws SQLException {
             try {
                 Class.forName("com.mysql.cj.jdbc.Driver");
             } catch (ClassNotFoundException e) {
                 throw new SQLException("MySQL Driver not found", e);
             }
             return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
         }
         
        /**
         * Auto generated method signature
         * 
                                     * @param consultar0 
             * @return consultarResponse1 
         */
        
                 public org.example.www.controlaccesos.ConsultarResponse consultar
                  (
                  org.example.www.controlaccesos.Consultar consultar0
                  )
            {
                	 ConsultarResponse response = new ConsultarResponse();

                	    try (Connection conn = getConnection()) {

                	        String sql = "SELECT ra.id, ra.idEmpleado, ra.idSala, ra.idDispositivo, ra.fechaHora " +
                	                     "FROM registroaccesos ra " +
                	                     "JOIN empleados e ON ra.idEmpleado = e.id " +
                	                     "JOIN salas s ON ra.idSala = s.id " +
                	                     "JOIN dispositivo d ON ra.idDispositivo = d.id " +
                	                     "WHERE e.nifnie = ? " +
                	                     "AND s.codigoSala = ? " +
                	                     "AND d.codigo = ? " +
                	                     "AND ra.fechaHora BETWEEN ? AND ?";

                	        PreparedStatement ps = conn.prepareStatement(sql);
                	        ps.setString(1, consultar0.getNif());
                	        ps.setInt(2, consultar0.getCodigosala());
                	        ps.setInt(3, consultar0.getCodigodispositivo());
                	        ps.setString(4, consultar0.getFechaInc());
                	        ps.setString(5, consultar0.getFechaFin());

                	        ResultSet rs = ps.executeQuery();

                	        java.util.List<Registroaccesos> lista = new java.util.ArrayList<>();
                	        while (rs.next()) {
                	            Registroaccesos reg = new Registroaccesos();
                	            reg.setId(rs.getInt("id"));
                	            reg.setIdEmpleado(rs.getInt("idEmpleado"));
                	            reg.setIdSala(rs.getInt("idSala"));
                	            reg.setIdDispositivo(rs.getInt("idDispositivo"));

                	            java.util.Calendar cal = java.util.Calendar.getInstance();
                	            cal.setTimeInMillis(rs.getTimestamp("fechaHora").getTime());
                	            reg.setFechaHora(cal);

                	            lista.add(reg);
                	        }

                	        ArrayOfRegistroAcceso arrayOut = new ArrayOfRegistroAcceso();
                	        arrayOut.setRegistroccesos(lista.toArray(new Registroaccesos[0]));
                	        response.setOut(arrayOut);

                	    } catch (SQLException e) {
                	        System.out.println(">>> SQL ERROR consultar: " + e.getMessage());
                	        e.printStackTrace();
                	        response.setOut(new ArrayOfRegistroAcceso());
                	    }
                	    return response;
                
        }
     
         
        /**
         * Auto generated method signature
         * 
                                     * @param registrar2 
             * @return registrarResponse3 
         */
        
                 public org.example.www.controlaccesos.RegistrarResponse registrar
                  (
                  org.example.www.controlaccesos.Registrar registrar2
                  )
            {
                	 RegistrarResponse response = new RegistrarResponse();

                     try (Connection conn = getConnection()) {

                         PreparedStatement psEmp = conn.prepareStatement(
                             "SELECT id FROM empleados WHERE nifnie = ?");
                         psEmp.setString(1, registrar2.getNif());
                         ResultSet rsEmp = psEmp.executeQuery();
                         System.out.println(">>> NIF buscado: [" + registrar2.getNif() + "]");
                         if (!rsEmp.next()) {
                             System.out.println(">>> FALLO: empleado no encontrado");
                             response.setOut(false); return response;
                         }
                         int idEmpleado = rsEmp.getInt("id");
                         System.out.println(">>> idEmpleado: " + idEmpleado);

                         
                         PreparedStatement psSala = conn.prepareStatement(
                             "SELECT id FROM salas WHERE codigoSala = ?");
                         psSala.setInt(1, registrar2.getCodigosala());
                         ResultSet rsSala = psSala.executeQuery();
                         System.out.println(">>> codigoSala buscado: [" + registrar2.getCodigosala() + "]");
                         if (!rsSala.next()) {
                             System.out.println(">>> FALLO: sala no encontrada");
                             response.setOut(false); return response;
                         }
                         int idSala = rsSala.getInt("id");
                         System.out.println(">>> idSala: " + idSala);

                         
                         PreparedStatement psDisp = conn.prepareStatement(
                             "SELECT id FROM dispositivo WHERE codigo = ?");
                         psDisp.setInt(1, registrar2.getCodigodispositivo());
                         ResultSet rsDisp = psDisp.executeQuery();
                         System.out.println(">>> codigoDispositivo buscado: [" + registrar2.getCodigodispositivo() + "]");
                         if (!rsDisp.next()) {
                             System.out.println(">>> FALLO: dispositivo no encontrado");
                             response.setOut(false); return response;
                         }
                         int idDispositivo = rsDisp.getInt("id");
                         System.out.println(">>> idDispositivo: " + idDispositivo);

                         PreparedStatement psInsert = conn.prepareStatement(
                             "INSERT INTO registroaccesos (idEmpleado, idSala, idDispositivo, fechaHora) " +
                             "VALUES (?, ?, ?, NOW())");
                         psInsert.setInt(1, idEmpleado);
                         psInsert.setInt(2, idSala);
                         psInsert.setInt(3, idDispositivo);
                         psInsert.executeUpdate();
                         response.setOut(true);

                     } catch (SQLException e) {
                         System.out.println(">>> SQL ERROR registrar: " + e.getMessage());
                         e.printStackTrace();
                         response.setOut(false);
                     }
                     return response;
        }
     
    }
    